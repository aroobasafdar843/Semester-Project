#include <iostream>
#include <conio.h>
using namespace std;
class gpa{
	public:
	float gpa1(float sgpa, float ch)
	{
		float calc = sgpa * ch;
		return calc;
	}
};
int main(int argc, char** argv) {
	float subgpa,subch,Gpa;
	float tgpa=0;
	float tch=0;
	int c;
	gpa gcalc;
	cout<<"Enter Number of Subjects : ";
	cin>>c;
	for(int i =0 ; i<c ; i++)
	{
		cout<<"Enter GPA of Subject : "<<i+1<<endl;
		cin>>subgpa;
		cout<<"Enter Credit Hours of Subject : "<<i+1<<endl;
		cin>>subch;
		tgpa = tgpa +gcalc.gpa1(subgpa,subch);
		tch = tch + subch;
	}
	Gpa=tgpa/tch;
	cout<<"Your GPA Is : "<<Gpa;
	return 0;
}
